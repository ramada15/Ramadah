// يجلب بيانات Alpaca بأمان: المفاتيح تُقرأ من Environment variables ولا تظهر للمتصفح
const json = (code, body) => ({
  statusCode: code,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  const id = process.env.ALPACA_KEY_ID;
  const secret = process.env.ALPACA_SECRET_KEY;
  if (!id || !secret) {
    return json(500, { error: "مفاتيح Alpaca غير مضافة في Netlify (ALPACA_KEY_ID و ALPACA_SECRET_KEY)" });
  }
  const symbols = (event.queryStringParameters?.symbols || "SPY")
    .toUpperCase().replace(/[^A-Z,.]/g, "").split(",").filter(Boolean).slice(0, 10).join(",");
  if (!symbols) return json(400, { error: "لا توجد رموز صالحة" });

  const headers = { "APCA-API-KEY-ID": id, "APCA-API-SECRET-KEY": secret };
  const base = "https://data.alpaca.markets/v2/stocks";
  const from = (days) => new Date(Date.now() - days * 864e5).toISOString();
  const get = async (path) => {
    const r = await fetch(base + path, { headers });
    if (!r.ok) throw new Error(`Alpaca ${r.status}: ${(await r.text()).slice(0, 200)}`);
    return r.json();
  };

  try {
    const [daily, intra, snaps] = await Promise.all([
      get(`/bars?symbols=${symbols}&timeframe=1Day&start=${from(20)}&limit=10000&feed=iex&adjustment=raw`),
      get(`/bars?symbols=${symbols}&timeframe=5Min&start=${from(5)}&limit=10000&feed=iex&adjustment=raw`),
      get(`/snapshots?symbols=${symbols}&feed=iex`),
    ]);
    return json(200, { daily: daily.bars || {}, intraday: intra.bars || {}, snapshots: snaps });
  } catch (e) {
    return json(502, { error: e.message });
  }
};
